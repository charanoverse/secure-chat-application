__version__ = "0.1.0"

# optional: expose the app if you want
from .cli import app